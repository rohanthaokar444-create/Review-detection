import { useState } from "react";

const NAV = [
  { icon: "⬡", label: "Dashboard", id: "dashboard" },
  { icon: "◎", label: "Analyze URL", id: "analyze" },
  { icon: "⊞", label: "Review Feed", id: "feed" },
  { icon: "⋮⋮", label: "Signal Map", id: "signals" },
  { icon: "⊙", label: "Reports", id: "reports" },
];

const MOCK_REVIEWS = [
  {
    id: 1,
    text: "Absolutely amazing product! Best purchase I've ever made in my entire life. 10/10 would recommend to everyone!",
    rating: 5,
    author: "john_buyer99",
    date: "Aug 18, 2026",
    risk: 91,
    verdict: "FAKE",
    signals: ["Hyperbolic language", "No specifics", "New account"],
  },
  {
    id: 2,
    text: "The build quality is solid and shipping was 3 days. Minor issue with the packaging but the product itself works exactly as described.",
    rating: 4,
    author: "TechReviewer_M",
    date: "Aug 14, 2026",
    risk: 12,
    verdict: "GENUINE",
    signals: ["Specific detail", "Balanced tone", "Verified purchase"],
  },
  {
    id: 3,
    text: "Good product. Fast delivery. Will order again.",
    rating: 5,
    author: "user_48291",
    date: "Aug 19, 2026",
    risk: 67,
    verdict: "SUSPICIOUS",
    signals: ["Generic phrasing", "No detail", "Pattern match"],
  },
  {
    id: 4,
    text: "I've been using this for 3 weeks now. The battery lasts about 6 hours which matches the specs. Bluetooth range is around 8m before dropout.",
    rating: 4,
    author: "AudioEnthusiast_K",
    date: "Aug 10, 2026",
    risk: 8,
    verdict: "GENUINE",
    signals: ["Measured claims", "Specific data", "Long account history"],
  },
  {
    id: 5,
    text: "LOVE LOVE LOVE this!!! Changed my life completely. Everyone needs this product NOW!!!",
    rating: 5,
    author: "happyshopper2026",
    date: "Aug 20, 2026",
    risk: 88,
    verdict: "FAKE",
    signals: ["Urgency language", "All-caps pattern", "24h account"],
  },
];

const SIGNALS = [
  { label: "Linguistic Entropy Score", value: 0.31, max: 1, note: "Low entropy = templated text" },
  { label: "Reviewer Account Age", value: 0.82, max: 1, note: "Avg 4.2 days old across fakes" },
  { label: "Review Burst Clustering", value: 0.74, max: 1, note: "67% posted within 48h window" },
  { label: "Sentiment Polarity Skew", value: 0.88, max: 1, note: "Extreme positive/negative bias" },
  { label: "Specificity Index", value: 0.19, max: 1, note: "Low detail in flagged reviews" },
  { label: "Cross-Platform Match", value: 0.41, max: 1, note: "Identical text on 3 platforms" },
];

const RECENT_SCANS = [
  { url: "amazon.com/dp/B09X234", trust: 61, reviews: 412, fake: 38 },
  { url: "trustpilot.com/review/shopify-store", trust: 84, reviews: 129, fake: 9 },
  { url: "yelp.com/biz/downtown-cafe", trust: 47, reviews: 88, fake: 52 },
  { url: "g2.com/products/crm-tool", trust: 92, reviews: 340, fake: 4 },
];

function TrustRing({ score, size = 120 }: { score: number; size?: number }) {
  const r = 46;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  const color = score >= 75 ? "#10b981" : score >= 50 ? "#f59e0b" : "#ef4444";
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
      <circle
        cx="50" cy="50" r={r}
        fill="none"
        stroke={color}
        strokeWidth="8"
        strokeLinecap="round"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        transform="rotate(-90 50 50)"
        className="score-ring"
        style={{ filter: `drop-shadow(0 0 6px ${color}80)` }}
      />
      <text x="50" y="46" textAnchor="middle" fill={color} fontSize="20" fontFamily="Outfit,sans-serif" fontWeight="700">{score}</text>
      <text x="50" y="60" textAnchor="middle" fill="#6b7a99" fontSize="8" fontFamily="Inter,sans-serif">TRUST SCORE</text>
    </svg>
  );
}

function RiskBadge({ verdict }: { verdict: string }) {
  if (verdict === "FAKE") return <span className="tag tag-red">● FAKE</span>;
  if (verdict === "SUSPICIOUS") return <span className="tag tag-amber">◑ SUSPICIOUS</span>;
  return <span className="tag tag-green">✓ GENUINE</span>;
}

function RiskBar({ value, max = 1 }: { value: number; max?: number }) {
  const pct = Math.round((value / max) * 100);
  const color = pct > 70 ? "#ef4444" : pct > 40 ? "#f59e0b" : "#10b981";
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
        <div
          className="h-full rounded-full transition-all duration-1000"
          style={{ width: `${pct}%`, background: color, boxShadow: `0 0 8px ${color}60` }}
        />
      </div>
      <span className="font-mono-data text-xs" style={{ color, minWidth: 32 }}>{pct}%</span>
    </div>
  );
}

export default function App() {
  const [activeNav, setActiveNav] = useState("analyze");
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);
  const [trustScore] = useState(58);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleAnalyze = () => {
    if (!url.trim()) return;
    setLoading(true);
    setAnalyzed(false);
    setTimeout(() => {
      setLoading(false);
      setAnalyzed(true);
      setActiveNav("analyze");
    }, 2200);
  };

  const fakeCount = MOCK_REVIEWS.filter(r => r.verdict === "FAKE").length;
  const suspiciousCount = MOCK_REVIEWS.filter(r => r.verdict === "SUSPICIOUS").length;
  const genuineCount = MOCK_REVIEWS.filter(r => r.verdict === "GENUINE").length;

  return (
    <div className="flex h-screen overflow-hidden grid-bg" style={{ background: "#080c14" }}>
      {/* Ambient glow blobs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div style={{
          position: "absolute", top: -120, left: -80,
          width: 600, height: 600,
          background: "radial-gradient(circle, rgba(0,212,184,0.06) 0%, transparent 70%)",
          borderRadius: "50%"
        }} />
        <div style={{
          position: "absolute", bottom: -100, right: -60,
          width: 500, height: 500,
          background: "radial-gradient(circle, rgba(124,92,252,0.07) 0%, transparent 70%)",
          borderRadius: "50%"
        }} />
      </div>

      {/* Sidebar */}
      <aside
        className="flex-shrink-0 flex flex-col border-r z-10 transition-all duration-300"
        style={{
          width: sidebarOpen ? 220 : 60,
          background: "rgba(13,20,36,0.95)",
          borderColor: "rgba(255,255,255,0.07)",
          backdropFilter: "blur(24px)"
        }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
          <div className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #00d4b8, #7c5cfc)", boxShadow: "0 0 16px rgba(0,212,184,0.3)" }}>
            <span className="font-display font-800 text-sm text-white">R</span>
          </div>
          {sidebarOpen && (
            <div>
              <div className="font-display font-700 text-sm leading-none" style={{ color: "#e2e8f0" }}>RevVue</div>
              <div className="font-mono-data text-xs mt-0.5" style={{ color: "#00d4b8", fontSize: 9 }}>AI TRUST ENGINE</div>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-4 flex flex-col gap-0.5 overflow-y-auto">
          {NAV.map(item => (
            <button
              key={item.id}
              className={`nav-item ${activeNav === item.id ? "active" : ""}`}
              style={{ justifyContent: sidebarOpen ? "flex-start" : "center" }}
              onClick={() => setActiveNav(item.id)}
            >
              <span style={{ fontSize: 15, opacity: 0.9 }}>{item.icon}</span>
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* Bottom */}
        <div className="px-2 py-4 border-t" style={{ borderColor: "rgba(255,255,255,0.07)" }}>
          {sidebarOpen && (
            <div className="px-3 py-2.5 rounded-lg mb-2" style={{ background: "rgba(0,212,184,0.06)", border: "1px solid rgba(0,212,184,0.12)" }}>
              <div className="flex items-center gap-2 mb-1">
                <div className="status-dot animate-pulse-dot" />
                <span className="font-mono-data text-xs" style={{ color: "#00d4b8" }}>ENGINE ONLINE</span>
              </div>
              <div className="font-mono-data text-xs" style={{ color: "#6b7a99", fontSize: 10 }}>API v2.4.1 · 98.7% uptime</div>
            </div>
          )}
          <button
            className="nav-item w-full"
            style={{ justifyContent: sidebarOpen ? "flex-start" : "center" }}
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <span style={{ fontSize: 14 }}>{sidebarOpen ? "←" : "→"}</span>
            {sidebarOpen && <span style={{ fontSize: 12 }}>Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        {/* Top bar */}
        <header className="sticky top-0 z-10 flex items-center justify-between px-6 py-3 border-b"
          style={{ background: "rgba(8,12,20,0.9)", borderColor: "rgba(255,255,255,0.07)", backdropFilter: "blur(16px)" }}>
          <div>
            <h1 className="font-display font-600 text-base" style={{ color: "#e2e8f0" }}>
              {activeNav === "analyze" && "Analyze URL"}
              {activeNav === "dashboard" && "Dashboard"}
              {activeNav === "feed" && "Review Feed"}
              {activeNav === "signals" && "Signal Map"}
              {activeNav === "reports" && "Reports"}
            </h1>
            <p className="font-mono-data text-xs" style={{ color: "#6b7a99", fontSize: 10, marginTop: 1 }}>
              RevVue AI · Fake Review Intelligence
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg" style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.15)" }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#10b981", boxShadow: "0 0 6px #10b98180" }} />
              <span className="font-mono-data" style={{ color: "#34d399", fontSize: 11 }}>LIVE</span>
            </div>
            <div className="w-8 h-8 rounded-full flex items-center justify-center font-display font-600 text-sm"
              style={{ background: "linear-gradient(135deg, #7c5cfc, #00d4b8)", color: "white" }}>
              A
            </div>
          </div>
        </header>

        <div className="p-6">
          {/* ANALYZE VIEW */}
          {activeNav === "analyze" && (
            <div className="max-w-4xl mx-auto">
              {/* Hero */}
              <div className="mb-8 text-center">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4"
                  style={{ background: "rgba(0,212,184,0.08)", border: "1px solid rgba(0,212,184,0.2)" }}>
                  <div className="status-dot animate-pulse-dot" />
                  <span className="font-mono-data text-xs" style={{ color: "#00d4b8" }}>NEURAL ENGINE ACTIVE · 2026</span>
                </div>
                <h2 className="font-display font-800 mb-3" style={{ fontSize: 42, lineHeight: 1.1, color: "#e2e8f0" }}>
                  Detect Fake Reviews<br />
                  <span className="text-gradient-teal">with AI Precision</span>
                </h2>
                <p className="text-base max-w-md mx-auto" style={{ color: "#94a3b8", lineHeight: 1.6 }}>
                  Paste any product page or review URL. RevVue's engine extracts, classifies, and scores every review for authenticity.
                </p>
              </div>

              {/* URL Input */}
              <div className="glass-strong rounded-2xl p-5 mb-6 glow-teal">
                <div className="flex items-center gap-2 mb-3">
                  <span className="font-mono-data text-xs" style={{ color: "#6b7a99" }}>TARGET URL</span>
                </div>
                <div className="flex gap-3">
                  <div className="flex-1 flex items-center gap-3 rounded-xl px-4 py-3"
                    style={{ background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.08)" }}>
                    <span style={{ color: "#6b7a99", fontSize: 14 }}>⊕</span>
                    <input
                      type="text"
                      className="flex-1 bg-transparent text-sm"
                      placeholder="https://amazon.com/dp/B09X... or any review page"
                      value={url}
                      onChange={e => setUrl(e.target.value)}
                      onKeyDown={e => e.key === "Enter" && handleAnalyze()}
                      style={{ color: "#e2e8f0", fontFamily: "Inter, sans-serif" }}
                    />
                    {url && (
                      <button onClick={() => setUrl("")} style={{ color: "#6b7a99", fontSize: 12 }}>✕</button>
                    )}
                  </div>
                  <button
                    onClick={handleAnalyze}
                    disabled={loading || !url.trim()}
                    className="flex items-center gap-2 px-5 py-3 rounded-xl font-display font-600 text-sm transition-all duration-200"
                    style={{
                      background: loading || !url.trim()
                        ? "rgba(255,255,255,0.06)"
                        : "linear-gradient(135deg, #00d4b8, #7c5cfc)",
                      color: loading || !url.trim() ? "#6b7a99" : "white",
                      cursor: loading || !url.trim() ? "not-allowed" : "pointer",
                      boxShadow: loading || !url.trim() ? "none" : "0 0 24px rgba(0,212,184,0.3)",
                      minWidth: 120
                    }}
                  >
                    {loading ? (
                      <>
                        <span style={{ display: "inline-block", animation: "spin 1s linear infinite", fontSize: 12 }}>◌</span>
                        Scanning...
                      </>
                    ) : "Analyze →"}
                  </button>
                </div>

                {/* Loading state */}
                {loading && (
                  <div className="mt-4 space-y-2">
                    {["Fetching page content...", "Extracting review nodes...", "Running AI classifier..."].map((step, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div style={{
                          width: 6, height: 6, borderRadius: "50%",
                          background: "#00d4b8",
                          boxShadow: "0 0 8px rgba(0,212,184,0.8)",
                          animation: `pulse-dot ${0.8 + i * 0.4}s ease infinite`
                        }} />
                        <span className="font-mono-data text-xs" style={{ color: "#6b7a99" }}>{step}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Results */}
              {analyzed && (
                <div className="animate-fade-in-up space-y-5">
                  {/* Score summary */}
                  <div className="grid gap-4" style={{ gridTemplateColumns: "1fr 1fr 1fr 1fr" }}>
                    {[
                      { label: "Trust Score", value: `${trustScore}`, unit: "/100", color: "#f59e0b" },
                      { label: "Reviews Scanned", value: `${MOCK_REVIEWS.length}`, unit: "total", color: "#00d4b8" },
                      { label: "Flagged Fake", value: `${fakeCount}`, unit: "reviews", color: "#ef4444" },
                      { label: "Risk Level", value: "MED", unit: "", color: "#f59e0b" },
                    ].map((stat, i) => (
                      <div key={i} className="glass rounded-xl p-4 text-center">
                        <div className="font-display font-700 text-2xl mb-0.5" style={{ color: stat.color }}>{stat.value}<span className="text-sm font-400 ml-1" style={{ color: "#6b7a99" }}>{stat.unit}</span></div>
                        <div className="font-mono-data text-xs" style={{ color: "#6b7a99", fontSize: 10 }}>{stat.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* Trust ring + breakdown */}
                  <div className="glass rounded-2xl p-5 flex gap-8 items-center">
                    <div className="flex-shrink-0">
                      <TrustRing score={trustScore} size={140} />
                    </div>
                    <div className="flex-1">
                      <div className="mb-4">
                        <span className="font-display font-600 text-base" style={{ color: "#e2e8f0" }}>Site Trust Assessment</span>
                        <p className="font-mono-data text-xs mt-1" style={{ color: "#6b7a99", fontSize: 11 }}>
                          {url.slice(0, 50)}{url.length > 50 ? "..." : ""}
                        </p>
                      </div>
                      <div className="space-y-3">
                        {[
                          { label: "Fake Reviews", count: fakeCount, total: MOCK_REVIEWS.length, color: "#ef4444" },
                          { label: "Suspicious Reviews", count: suspiciousCount, total: MOCK_REVIEWS.length, color: "#f59e0b" },
                          { label: "Genuine Reviews", count: genuineCount, total: MOCK_REVIEWS.length, color: "#10b981" },
                        ].map((item, i) => (
                          <div key={i}>
                            <div className="flex justify-between mb-1">
                              <span className="font-mono-data text-xs" style={{ color: "#94a3b8", fontSize: 11 }}>{item.label}</span>
                              <span className="font-mono-data text-xs" style={{ color: item.color }}>{item.count}/{item.total}</span>
                            </div>
                            <div className="h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
                              <div className="h-full rounded-full transition-all duration-1000"
                                style={{ width: `${(item.count / item.total) * 100}%`, background: item.color, boxShadow: `0 0 8px ${item.color}50` }} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Individual reviews */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-display font-600 text-sm" style={{ color: "#e2e8f0" }}>Individual Review Analysis</span>
                      <span className="font-mono-data text-xs" style={{ color: "#6b7a99" }}>{MOCK_REVIEWS.length} classified</span>
                    </div>
                    <div className="space-y-3">
                      {MOCK_REVIEWS.map((review, i) => (
                        <div key={review.id} className="glass rounded-xl p-4 animate-fade-in-up"
                          style={{ animationDelay: `${i * 80}ms` }}>
                          <div className="flex items-start justify-between gap-4 mb-3">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1.5">
                                <div className="w-6 h-6 rounded-full flex items-center justify-center font-display font-700 text-xs"
                                  style={{ background: "rgba(255,255,255,0.08)", color: "#94a3b8" }}>
                                  {review.author[0].toUpperCase()}
                                </div>
                                <span className="font-mono-data text-xs" style={{ color: "#94a3b8" }}>{review.author}</span>
                                <span className="font-mono-data text-xs" style={{ color: "#4b5563", fontSize: 10 }}>{review.date}</span>
                                <span style={{ color: "#f59e0b", fontSize: 11 }}>{"★".repeat(review.rating)}</span>
                              </div>
                              <p className="text-sm leading-relaxed" style={{ color: "#cbd5e1" }}>{review.text}</p>
                            </div>
                            <div className="flex flex-col items-end gap-2 flex-shrink-0">
                              <RiskBadge verdict={review.verdict} />
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono-data text-xs" style={{ color: "#6b7a99", fontSize: 10 }}>RISK</span>
                                <span className="font-mono-data font-600 text-sm"
                                  style={{ color: review.risk > 70 ? "#ef4444" : review.risk > 40 ? "#f59e0b" : "#10b981" }}>
                                  {review.risk}%
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 flex-wrap pt-2 border-t" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
                            {review.signals.map((sig, j) => (
                              <span key={j} className="tag" style={{
                                background: review.verdict === "FAKE" ? "rgba(239,68,68,0.08)" : review.verdict === "SUSPICIOUS" ? "rgba(245,158,11,0.08)" : "rgba(16,185,129,0.08)",
                                color: review.verdict === "FAKE" ? "#f87171" : review.verdict === "SUSPICIOUS" ? "#fbbf24" : "#34d399",
                                border: `1px solid ${review.verdict === "FAKE" ? "rgba(239,68,68,0.18)" : review.verdict === "SUSPICIOUS" ? "rgba(245,158,11,0.18)" : "rgba(16,185,129,0.18)"}`,
                                fontSize: 10
                              }}>{sig}</span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Empty state when not analyzed */}
              {!analyzed && !loading && (
                <div className="glass rounded-2xl p-10 text-center">
                  <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: "rgba(0,212,184,0.08)", border: "1px solid rgba(0,212,184,0.15)" }}>
                    <span style={{ fontSize: 28, color: "#00d4b8" }}>⊕</span>
                  </div>
                  <p className="font-display font-500 text-base mb-1" style={{ color: "#94a3b8" }}>Enter a URL to begin analysis</p>
                  <p className="font-mono-data text-xs" style={{ color: "#4b5563" }}>Supports Amazon, Trustpilot, Yelp, G2, Google Reviews, and more</p>
                </div>
              )}
            </div>
          )}

          {/* DASHBOARD VIEW */}
          {activeNav === "dashboard" && (
            <div className="max-w-5xl mx-auto">
              <div className="grid gap-4 mb-6" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
                {[
                  { label: "Total Scans", value: "1,284", delta: "+12 today", color: "#00d4b8" },
                  { label: "Reviews Analyzed", value: "48.3K", delta: "+892 today", color: "#7c5cfc" },
                  { label: "Fakes Detected", value: "9,421", delta: "19.5% rate", color: "#ef4444" },
                  { label: "Sites Monitored", value: "64", delta: "active", color: "#10b981" },
                ].map((stat, i) => (
                  <div key={i} className="glass rounded-xl p-5">
                    <div className="font-mono-data text-xs mb-2" style={{ color: "#6b7a99", fontSize: 10 }}>{stat.label.toUpperCase()}</div>
                    <div className="font-display font-700 text-2xl mb-1" style={{ color: stat.color }}>{stat.value}</div>
                    <div className="font-mono-data text-xs" style={{ color: "#4b5563", fontSize: 10 }}>{stat.delta}</div>
                  </div>
                ))}
              </div>

              <div className="grid gap-4" style={{ gridTemplateColumns: "1fr 1.4fr" }}>
                <div className="glass rounded-2xl p-5">
                  <div className="font-display font-600 text-sm mb-4" style={{ color: "#e2e8f0" }}>Recent Scans</div>
                  <div className="space-y-3">
                    {RECENT_SCANS.map((scan, i) => (
                      <div key={i} className="flex items-center gap-3 py-2 border-b" style={{ borderColor: "rgba(255,255,255,0.04)" }}>
                        <TrustRing score={scan.trust} size={44} />
                        <div className="flex-1 min-w-0">
                          <div className="font-mono-data text-xs truncate" style={{ color: "#94a3b8", fontSize: 11 }}>{scan.url}</div>
                          <div className="font-mono-data text-xs mt-0.5" style={{ color: "#4b5563", fontSize: 10 }}>
                            {scan.reviews} reviews · <span style={{ color: "#ef4444" }}>{scan.fake}% flagged</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="glass rounded-2xl p-5">
                  <div className="font-display font-600 text-sm mb-4" style={{ color: "#e2e8f0" }}>Detection Signals</div>
                  <div className="space-y-4">
                    {SIGNALS.map((sig, i) => (
                      <div key={i}>
                        <div className="flex justify-between mb-1.5">
                          <span className="text-xs" style={{ color: "#94a3b8" }}>{sig.label}</span>
                          <span className="font-mono-data text-xs" style={{ color: "#6b7a99", fontSize: 10 }}>{sig.note}</span>
                        </div>
                        <RiskBar value={sig.value} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* REVIEW FEED VIEW */}
          {activeNav === "feed" && (
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center gap-3 mb-5">
                <span className="tag tag-teal">All</span>
                <span className="tag tag-red">Fake</span>
                <span className="tag tag-amber">Suspicious</span>
                <span className="tag tag-green">Genuine</span>
              </div>
              <div className="space-y-3">
                {MOCK_REVIEWS.map((review, i) => (
                  <div key={review.id} className="glass rounded-xl p-5">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-7 h-7 rounded-full flex items-center justify-center font-display font-700 text-xs"
                            style={{ background: "linear-gradient(135deg, rgba(0,212,184,0.2), rgba(124,92,252,0.2))", color: "#94a3b8" }}>
                            {review.author[0].toUpperCase()}
                          </div>
                          <span className="font-mono-data text-xs" style={{ color: "#94a3b8" }}>{review.author}</span>
                          <span className="font-mono-data text-xs" style={{ color: "#4b5563", fontSize: 10 }}>{review.date}</span>
                        </div>
                        <p className="text-sm" style={{ color: "#cbd5e1", lineHeight: 1.6 }}>{review.text}</p>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <RiskBadge verdict={review.verdict} />
                        <div className="font-mono-data font-600 text-lg"
                          style={{ color: review.risk > 70 ? "#ef4444" : review.risk > 40 ? "#f59e0b" : "#10b981" }}>
                          {review.risk}%
                        </div>
                        <div className="font-mono-data text-xs" style={{ color: "#6b7a99", fontSize: 9 }}>RISK SCORE</div>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {review.signals.map((sig, j) => (
                        <span key={j} className="tag" style={{ fontSize: 10,
                          background: "rgba(255,255,255,0.04)", color: "#6b7a99", border: "1px solid rgba(255,255,255,0.07)" }}>
                          {sig}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SIGNALS VIEW */}
          {activeNav === "signals" && (
            <div className="max-w-3xl mx-auto">
              <div className="glass rounded-2xl p-6 mb-5">
                <div className="font-display font-600 text-base mb-1" style={{ color: "#e2e8f0" }}>AI Signal Breakdown</div>
                <p className="text-sm mb-6" style={{ color: "#6b7a99" }}>Each signal contributes to the final risk classification. Higher scores indicate stronger evidence of manipulation.</p>
                <div className="space-y-5">
                  {SIGNALS.map((sig, i) => (
                    <div key={i} className="p-4 rounded-xl" style={{ background: "rgba(0,0,0,0.2)", border: "1px solid rgba(255,255,255,0.05)" }}>
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="font-display font-600 text-sm" style={{ color: "#e2e8f0" }}>{sig.label}</div>
                          <div className="font-mono-data text-xs mt-0.5" style={{ color: "#6b7a99", fontSize: 11 }}>{sig.note}</div>
                        </div>
                        <div className="font-display font-700 text-xl"
                          style={{ color: sig.value > 0.7 ? "#ef4444" : sig.value > 0.4 ? "#f59e0b" : "#10b981" }}>
                          {Math.round(sig.value * 100)}
                        </div>
                      </div>
                      <RiskBar value={sig.value} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* REPORTS VIEW */}
          {activeNav === "reports" && (
            <div className="max-w-3xl mx-auto">
              <div className="glass rounded-2xl p-8 text-center">
                <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                  style={{ background: "rgba(124,92,252,0.1)", border: "1px solid rgba(124,92,252,0.2)" }}>
                  <span style={{ fontSize: 24, color: "#7c5cfc" }}>⊞</span>
                </div>
                <div className="font-display font-600 text-base mb-2" style={{ color: "#e2e8f0" }}>Reports Coming Soon</div>
                <p className="text-sm" style={{ color: "#6b7a99" }}>Exportable PDF/CSV reports with full analysis history and trend tracking.</p>
                <div className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-lg"
                  style={{ background: "rgba(124,92,252,0.08)", border: "1px solid rgba(124,92,252,0.15)" }}>
                  <span className="font-mono-data text-xs" style={{ color: "#a78bfa" }}>Q3 2026 ROADMAP</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
